# Collective plan review skill

This overlay adds a second Codex skill focused on planning rather than implementation.

## What it does

Use `collective-plan-review` when you want Codex to:
1. investigate a request and the current repository,
2. draft an implementation plan,
3. send that draft to a swarm of reviewer subagents,
4. refine the plan based on their feedback,
5. stop before code changes.

## Recommended usage

1. Start Codex in the repository.
2. Switch to plan mode with `/plan`.
3. Invoke the skill explicitly with `$collective-plan-review`.

Example prompt:

```text
/plan Use $collective-plan-review to investigate adding offline search result caching for the settings screen, propose an implementation plan, have the reviewer swarm stress-test it, and return the revised plan with the review ledger. Do not change code.
```

## Added project-scoped custom agents

- `requirements-critic`
- `architecture-planner`
- `risk-and-migration-reviewer`
- `validation-strategist`

These agents are discovered from `.codex/agents/*.toml`.

## Notes

- This skill is instruction-only. It does not require scripts.
- It is designed to be explicit-invocation only.
- It pairs well with a repository `AGENTS.md` that documents how plans should reference modules, tests, and validation steps.
